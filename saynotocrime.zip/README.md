# City-Without-Crime


Description :
  It is a simple website that manages online crime management system.
  Server Site Scripting done using PHP.
  For Database we used MYSQL.
  For Front-End we used HTML,CSS,JAVASCRIPT.
  
  
Project Url:
  Source : https://github.com/asishchourasia/City-Without-Crime.git
  
  
Name : Asish Kumar Chourasia.
